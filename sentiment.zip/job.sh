#!/bin/bash
python receive.py