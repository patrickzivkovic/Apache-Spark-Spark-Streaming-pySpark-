search = ['black']
exit = False